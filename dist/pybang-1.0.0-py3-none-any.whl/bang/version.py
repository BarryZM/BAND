# encoding: utf-8

# author: BrikerMan
# contact: eliyar917@gmail.com
# blog: https://eliyar.biz

# file: __version__.py.py
# time: 2019-05-20 16:32

__version__ = '1.0.0'
